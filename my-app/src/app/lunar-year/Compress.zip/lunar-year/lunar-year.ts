import { Component } from '@angular/core';

@Component({
  selector: 'app-lunar-year',
  standalone: false,
  templateUrl: './lunar-year.html',
  styleUrl: './lunar-year.css',
})
export class LunarYear {

  days: number[] = [];
  months: number[] = [];
  years: number[] = [];

  selectedDay!: number;
  selectedMonth!: number;
  selectedYear!: number;

  result: any = null;

  constructor() {
    for (let i = 1; i <= 31; i++) this.days.push(i);
    for (let i = 1; i <= 12; i++) this.months.push(i);
    for (let i = 1980; i <= 2030; i++) this.years.push(i);

    this.selectedDay = 1;
    this.selectedMonth = 1;
    this.selectedYear = 2026;
  }

  /* ================== CORE ================== */

  convert() {
    const lunar = this.convertSolar2Lunar(
      this.selectedDay,
      this.selectedMonth,
      this.selectedYear,
      7
    );

    const date = new Date(
      this.selectedYear,
      this.selectedMonth - 1,
      this.selectedDay
    );

    const can = ['Giáp','Ất','Bính','Đinh','Mậu','Kỷ','Canh','Tân','Nhâm','Quý'];
    const chi = ['Tý','Sửu','Dần','Mão','Thìn','Tỵ','Ngọ','Mùi','Thân','Dậu','Tuất','Hợi'];

    const lunarYear = lunar[2];
    const canIndex = (lunarYear - 4) % 10;
    const chiIndex = (lunarYear - 4) % 12;

    this.result = {
      weekDay: ['Chủ nhật','Thứ hai','Thứ ba','Thứ tư','Thứ năm','Thứ sáu','Thứ bảy'][date.getDay()],
      lunarDate: `${lunar[0]}/${lunar[1]}/${lunar[2]}`,
      lunarYearName: can[canIndex] + ' ' + chi[chiIndex],
      lunarMonthName: chi[(lunar[1] + 1) % 12],
      lunarDayName: chi[(lunar[0] + 1) % 12]
    };
  }

  clear() {
    this.result = null;
  }
  /* ========== THUẬT TOÁN ÂM LỊCH VN ========== */

  jdFromDate(dd: number, mm: number, yy: number): number {
    const a = Math.floor((14 - mm) / 12);
    const y = yy + 4800 - a;
    const m = mm + 12 * a - 3;
    let jd = dd + Math.floor((153 * m + 2) / 5)
      + 365 * y + Math.floor(y / 4)
      - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
    return jd;
  }

  getNewMoonDay(k: number, timeZone: number): number {
    const T = k / 1236.85;
    const T2 = T * T;
    const T3 = T2 * T;
    const dr = Math.PI / 180;
    let Jd1 = 2415020.75933 + 29.53058868 * k
      + 0.0001178 * T2 - 0.000000155 * T3;
    Jd1 += 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
    const M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
    const Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
    const F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
    let C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr)
      + 0.0021 * Math.sin(2 * dr * M)
      - 0.4068 * Math.sin(Mpr * dr)
      + 0.0161 * Math.sin(2 * dr * Mpr);
    let jdNew = Jd1 + C1;
    return Math.floor(jdNew + 0.5 + timeZone / 24);
  }

  convertSolar2Lunar(dd: number, mm: number, yy: number, timeZone: number) {
    const dayNumber = this.jdFromDate(dd, mm, yy);
    const k = Math.floor((dayNumber - 2415021) / 29.530588853);
    let monthStart = this.getNewMoonDay(k + 1, timeZone);
    if (monthStart > dayNumber) {
      monthStart = this.getNewMoonDay(k, timeZone);
    }
    const lunarDay = dayNumber - monthStart + 1;
    let lunarMonth = mm;
    let lunarYear = yy;
    if (lunarMonth >= 11) {
      lunarYear = yy;
    } else {
      lunarYear = yy - 1;
    }
    return [lunarDay, lunarMonth, lunarYear];
  }
}